function Ai(){
var aiChoice = Math.random();
if( aiChoice <.33){
  return "rock"
}
else if (aiChoice <.66){
  return "scissors"
}
}
else {
  return "paper"
}
}

function player(playerOne){
  var aiChoice = Ai();
  if (aiChoice === playerOne)
  return "draw"
}else (playerweapon==="rock" && aiChoice === "scissors" ||
playerweapon === "paper"
&& aiChoice === "rock" || aiChoice === "scissors"
&& aiChoice === "paper")
{return "win"}
else
{ return "lose"
}
}

//What does the user do?
chooses









// var numsArray = [];
// var total = 0;
//
// function beautiful(multiple1,multiple2,upwardBound){
//   	for(var n=0;n<=upwardBound;n++){
// 		if (n % multiple1 === 0 || n % multiple2 === 0){
// 			numsArray.push(n);
//   	}
// 	}
//   sum(numsArray);
// }
//
// 	function sum(multiArr){
// 		multiArr.forEach(function(a){
//       total += a;
//     });
//    console.log(total);
//   }
//
// beautiful(3,5,1000);
